تحديث تطبيق نور إلى الأبرار

الملفات داخل هذه الحزمة:
- index.html: صفحة التطبيق بعد تحديث اسم الصفحة إلى الأبرار.
- assets/app-icon.png: الأيقونة الأساسية.
- assets/ic_launcher_foreground.png: طبقة أيقونة أندرويد التكيفية.
- .github/workflows/build.yml: ملف بناء APK باسم الأبرار مع الأيقونة الجديدة.

طريقة تطبيق التحديث على مستودع GitHub الحالي Noor:
1) افتح المستودع: https://github.com/abdoallahmira00/Noor
2) استبدل ملف index.html بمحتوى/ملف index.html الموجود هنا.
3) ارفع مجلد assets بالكامل إلى جذر المستودع، بحيث يصبح المساران:
   assets/app-icon.png
   assets/ic_launcher_foreground.png
4) افتح .github/workflows/build.yml في GitHub، واضغط Edit، واستبدل محتواه بالكامل بمحتوى الملف الموجود هنا، ثم Commit changes.
5) افتح Actions ثم Build APK - Al Abrar ثم Run workflow.
6) بعد نجاح البناء نزّل Artifact باسم al-abrar-apk، وفك ضغطه، وثبّت app-debug.apk.

مهم:
- تم الإبقاء على appId = com.noor.prayer حتى يكون التحديث بنفس هوية التطبيق السابق قدر الإمكان.
- إذا رفض أندرويد التثبيت كتحديث بسبب توقيع مختلف، احذف النسخة القديمة أولاً ثم ثبّت الجديدة. حذف النسخة القديمة قد يمسح بياناتها المحلية.
